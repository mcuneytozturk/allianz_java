package model;

public class FlyingTurtle extends Villain{
    public FlyingTurtle(String name, int damage, boolean isMortal, int health, MoveTypeEnum moveTypeEnum, Coordinate coordinate) {
        super(name, damage, isMortal, health, moveTypeEnum, coordinate);
    }
}
