package model;

public class FireRotatingChain extends Villain{
    public FireRotatingChain(String name, int damage, boolean isMortal, int health, MoveTypeEnum moveTypeEnum, Coordinate coordinate) {
        super(name, damage, isMortal, health, moveTypeEnum, coordinate);
    }
}
