package model;

public class Luigi extends MarioBaseCharacter{
    public Luigi(String name, int health, GrowthCycleEnum growthCycleEnum, int length, boolean immortality, int remainingLife, Coordinate coordinate) {
        super(name, health, growthCycleEnum, length, immortality, remainingLife, coordinate);
    }
}
