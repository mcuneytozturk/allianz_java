package model;

public class AmazonMap extends Map{
    public AmazonMap(String name, int xLength, int yLength) {
        super(name, xLength, yLength);
    }
}
