package model;

public enum GrowthCycleEnum {
    LITTLE, SUPER;
}
