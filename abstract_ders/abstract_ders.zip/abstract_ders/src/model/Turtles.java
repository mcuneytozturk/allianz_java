package model;

public class Turtles extends Villain{
    public Turtles(String name, int damage, boolean isMortal, int health, MoveTypeEnum moveTypeEnum, Coordinate coordinate) {
        super(name, damage, isMortal, health, moveTypeEnum, coordinate);
    }
}
