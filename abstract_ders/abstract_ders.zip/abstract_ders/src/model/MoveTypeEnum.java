package model;

public enum MoveTypeEnum {
    WALKER,FLYER,STANDER;
}
